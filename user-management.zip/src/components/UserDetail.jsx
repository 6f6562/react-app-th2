import { useParams, useNavigate } from "react-router-dom";
import { Card, Container, ListGroup, Button, Image, Row, Col } from "react-bootstrap";
import { useEffect, useState } from "react";

function UserDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [user, setUser] = useState(null);

  // Lấy danh sách user từ localStorage
  useEffect(() => {
    const storedUsers = JSON.parse(localStorage.getItem("users")) || [];
    const foundUser = storedUsers.find((u) => u.id === parseInt(id));

    if (!foundUser || !foundUser.isActive) {
      localStorage.setItem("lastInactiveUser", JSON.stringify(foundUser)); // Lưu user bị vô hiệu hóa vào localStorage
      navigate("/notfound");
    } else {
      setUser(foundUser);
    }
  }, [id, navigate]);

  if (!user) {
    return null;
  }

  return (
    <Container className="mt-5 d-flex justify-content-center">
      <Card className="shadow-lg p-4 rounded" style={{ width: "500px", border: "none" }}>
        <Card.Body className="text-center">
          <Image 
            src={`https://ui-avatars.com/api/?name=${encodeURIComponent(user.name)}&size=150&background=random`} 
            roundedCircle 
            className="mb-3 border border-3 border-primary"
            style={{ width: "120px", height: "120px" }}
          />
          <Card.Title className="mb-3" style={{ fontSize: "2rem", fontWeight: "bold", color: "#2c3e50" }}>
            {user.name}
          </Card.Title>

          <ListGroup variant="flush" className="text-start">
            <ListGroup.Item className="py-3" style={{ fontSize: "1.2rem" }}>
              <strong>📅 Tuổi:</strong> {user.age}
            </ListGroup.Item>
            <ListGroup.Item className="py-3" style={{ fontSize: "1.2rem" }}>
              <strong>📧 Email:</strong> {user.email}
            </ListGroup.Item>
            <ListGroup.Item className="py-3" style={{ fontSize: "1.2rem" }}>
              <strong>📞 Điện thoại:</strong> {user.phone}
            </ListGroup.Item>
            <ListGroup.Item className="py-3" style={{ fontSize: "1.2rem" }}>
              <strong>🏠 Địa chỉ:</strong> {user.address}
            </ListGroup.Item>
          </ListGroup>

          <Row className="mt-4">
            <Col>
              <Button 
                variant="primary" 
                className="w-100 py-2" 
                onClick={() => navigate("/")}
                style={{ fontSize: "1.4rem", fontWeight: "bold", padding: "12px 0" }}
              >
                ⬅ Quay lại danh sách
              </Button>
            </Col>
          </Row>
        </Card.Body>
      </Card>
    </Container>
  );
}

export default UserDetail;
