import { useState, useEffect } from "react";
import { Container, Table, Button, Badge } from "react-bootstrap";
import { useNavigate } from "react-router-dom";

// Hàm lấy dữ liệu user từ localStorage hoặc dùng danh sách mặc định
const getStoredUsers = () => {
  const storedUsers = localStorage.getItem("users");
  return storedUsers
    ? JSON.parse(storedUsers)
    : [
        { id: 1, name: "Nguyễn Văn A", age: 25, email: "a@example.com", phone: "0123456789", address: "Hà Nội", isActive: true },
        { id: 2, name: "Trần Thị B", age: 30, email: "b@example.com", phone: "0987654321", address: "TP. Hồ Chí Minh", isActive: false },
        { id: 3, name: "Lê Văn C", age: 28, email: "c@example.com", phone: "0345678901", address: "Đà Nẵng", isActive: true }
      ];
};

function UserList() {
  const [users, setUsers] = useState(getStoredUsers());
  const navigate = useNavigate();

  // Cập nhật dữ liệu vào localStorage khi users thay đổi
  useEffect(() => {
    localStorage.setItem("users", JSON.stringify(users));
  }, [users]);

  const handleUserClick = (user) => {
    if (user.isActive) {
      navigate(`/user/${user.id}`);
    } else {
      navigate("/notfound", { state: { userName: user.name } });
    }
  };

  const toggleActive = (id, status) => {
    const updatedUsers = users.map((user) => (user.id === id ? { ...user, isActive: status } : user));
    setUsers(updatedUsers);
    localStorage.setItem("users", JSON.stringify(updatedUsers));
  };

  return (
    <Container className="mt-4">
      <h1 className="text-center mb-4">📋 Danh sách người dùng</h1>
      <Table striped bordered hover className="shadow">
        <thead className="table-dark">
          <tr className="text-center">
            <th>#</th>
            <th>Tên</th>
            <th>Trạng thái</th>
            <th>Hành động</th>
          </tr>
        </thead>
        <tbody>
          {users.map((user, index) => (
            <tr key={user.id} className="text-center">
              <td>{index + 1}</td>
              <td 
                style={{ cursor: "pointer", fontWeight: "bold" }} 
                className="text-primary"
                onClick={() => handleUserClick(user)}
              >
                {user.name}
              </td>
              <td>
                <Badge bg={user.isActive ? "success" : "danger"}>
                  {user.isActive ? "Active" : "Inactive"}
                </Badge>
              </td>
              <td>
                <Button
                  variant="success"
                  size="sm"
                  className="me-2"
                  onClick={() => toggleActive(user.id, true)}
                  disabled={user.isActive}
                >
                  ✅ Activate
                </Button>
                <Button
                  variant="danger"
                  size="sm"
                  onClick={() => toggleActive(user.id, false)}
                  disabled={!user.isActive}
                >
                  ❌ Deactivate
                </Button>
              </td>
            </tr>
          ))}
        </tbody>
      </Table>
    </Container>
  );
}

export default UserList;
