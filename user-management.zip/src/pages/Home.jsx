import UserList from "../components/UserList";
import { Container } from "react-bootstrap";

function Home() {
  return (
    <Container className="mt-4">
      <UserList />
    </Container>
  );
}

export default Home;
