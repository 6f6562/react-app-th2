import { useLocation } from "react-router-dom";
import { Container, Alert } from "react-bootstrap";

function NotFound() {
  const location = useLocation();
  const userName = location.state?.userName || "Người dùng";

  return (
    <Container className="mt-4 text-center">
      <Alert variant="danger">
        <h1>404 - {userName} đã bị xóa hoặc không tồn tại!</h1>
      </Alert>
    </Container>
  );
}

export default NotFound;
